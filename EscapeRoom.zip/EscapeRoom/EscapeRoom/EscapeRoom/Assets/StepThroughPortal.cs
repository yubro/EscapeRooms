﻿using UnityEngine;
using System.Collections;

public class StepThroughPortal : MonoBehaviour {

public GameObject otherPortal;
 	
	public StepThroughPortal exit;
    public GameObject thingToMove;
    public bool rgrab = false;
    public bool lgrab = false;
    public GameObject right_hand_grabbed;
    public GameObject left_hand_grabbed;
    Vector3 initial;
    Vector3 initialSize;
    // Use this for initialization
    void Start () {
        initial = thingToMove.transform.position;

    }
     
    // Update is called once per frame
    void Update () {
        if ((right_hand_grabbed = GameObject.Find("[Controller (right)]Original_Controller_AttachPoint").transform.parent.gameObject) != null)
        {
            rgrab = true;
        }
        else {
            rgrab = false;    
        }
        if ((left_hand_grabbed = GameObject.Find("[Controller (left)]Original_Controller_AttachPoint").transform.parent.gameObject) != null)
        {
            lgrab = true;
        }
        else {
            lgrab = false;
        }
    }
 
    void OnTriggerEnter(Collider other) {
        Debug.Log ("something hit the portal");
        if(other.tag == "Player") {
			exit.enabled = false;
			
            //thingToMove.transform.rotation = other.transform.rotation;
            if (gameObject.name == "Large Portal")
            {
                thingToMove.transform.position = new Vector3(otherPortal.transform.position.x, thingToMove.transform.position.y, otherPortal.transform.position.z);
                thingToMove.transform.localScale = new Vector3(0.1F, 0.1F, 0.2F);
                if (rgrab == true) {
                    ShrinkItem(right_hand_grabbed);
                }
                if (lgrab == true) {
                    ShrinkItem(left_hand_grabbed);
                }
                
            }

            if (gameObject.name == "Small Portal") {
                thingToMove.transform.position = initial;
                thingToMove.transform.localScale = new Vector3(1.0F, 1.0F, 1.0F);
                if (rgrab == true)
                {
                    ExpandItem(right_hand_grabbed);
                }
                if (lgrab == true)
                {
                    ExpandItem(left_hand_grabbed);
                }
            }
        }
	

    }

    void ShrinkItem(GameObject item) {
        item.transform.position = thingToMove.transform.position;
        item.transform.localScale = item.transform.localScale/10f;
    }

    void ExpandItem(GameObject item) {
        item.transform.position = thingToMove.transform.position;
        item.transform.localScale = item.transform.localScale*10f; ;
    }
}
