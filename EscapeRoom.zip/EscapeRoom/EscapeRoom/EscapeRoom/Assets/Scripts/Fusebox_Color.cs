﻿using UnityEngine;
using System.Collections;

public class Fusebox_Color : MonoBehaviour {

    private GameObject Light;
	private GameObject Portals;
    private bool red;
    private bool green;
    private bool blue;
    private bool power;

	// Use this for initialization
	void Start () {
        Light = GameObject.Find("RoomLight/Point Light");
		Portals = GameObject.Find("PortalsInWonderland");
		Portals.SetActive (false);
        Light.SetActive(false);

        red = false;
        green = false;
        blue = false;

        power = false;
    }
	
	public bool GetPower ()
    {
        return power;
    }

    public void Testfuses ()
    {
        red = GameObject.Find("Fusebox_Color/Fuse_red_in").GetComponent<MeshRenderer>().enabled;
        green = GameObject.Find("Fusebox_Color/Fuse_green_in").GetComponent<MeshRenderer>().enabled;
        blue = GameObject.Find("Fusebox_Color/Fuse_blue_in").GetComponent<MeshRenderer>().enabled;

        if(red && green && blue)
        {
            Light.SetActive(true);
			Portals.SetActive(true);
            power = true;
        }
    }
}
