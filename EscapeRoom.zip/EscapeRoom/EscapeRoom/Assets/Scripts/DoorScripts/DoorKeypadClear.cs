﻿namespace VRTK
{
    using UnityEngine;
    using System.Collections;

    public class DoorKeypadClear : VRTK_InteractableObject
    {

        public override void StartUsing(GameObject usingObject)
        {
            base.StartUsing(usingObject);
            if (GameObject.Find("DoorKeypad/ReaderTrigger").GetComponent<DoorKeyCard>().GetStatus())
            {
                GameObject.Find("DoorKeypad").GetComponent<AudioSource>().Play();
                GameObject.Find("DoorKeypad/KeypadDisplayInput").GetComponent<DoorKeypadInput>().ClearInput();
            }
        }

        // Use this for initialization
        protected override void Start()
        {
            base.Start();
        }
    }
}
