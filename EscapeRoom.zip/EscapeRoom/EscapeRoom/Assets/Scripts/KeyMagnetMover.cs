﻿using UnityEngine;
using System.Collections;

namespace VRTK
{
    public class KeyMagnetMover : MonoBehaviour
    {

        public float magnetStrength = 5f;
        public float distanceStrength = 10f;
        public int magnetDirection = 1;
        public bool looseMagnet = true;

        private Transform trans;
        private Rigidbody thisRB;
        private Transform magnetTrans;
        private bool magnetInZone;

        void Awake()
        {
            trans = transform;
            thisRB = trans.GetComponent<Rigidbody>();
        }

        void FixedUpdate()
        {
            if (magnetInZone && GameObject.Find("magnet/default").GetComponent<KeyMagnetController>().inUse == true)
            {

                Vector3 directionToMagnet = magnetTrans.position - trans.position;
                float distance = Vector3.Distance(magnetTrans.position, trans.position);
                float magnetDistanceStr = (distanceStrength / distance) * magnetStrength;
                //print("Magnet Fixed Update " + magnetDistanceStr * (directionToMagnet * magnetDirection));
                transform.parent.GetComponent<Rigidbody>().AddForce(magnetDistanceStr * (directionToMagnet * magnetDirection), ForceMode.Force);
            }
        }

        void OnTriggerEnter(Collider other)
        {
            //print("Trigger enter" + other.tag);
            if (other.tag == "Magnet" && GameObject.Find("magnet/default").GetComponent<KeyMagnetController>().inUse == true)
            {
                //print("Magnet in zone");
                magnetTrans = other.transform;
                magnetInZone = true;
            }
        }

        void OnTriggerExit(Collider other)
        {
            //print("Trigger exit");
            if (other.tag == "Magnet" && looseMagnet)
            {
                //print("Magnet out of zone");
                magnetInZone = false;
            }
        }
    }
}
