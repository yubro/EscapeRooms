﻿namespace VRTK
{
    using UnityEngine;
    using System.Collections;

    public class MagnetScript : VRTK_InteractableObject
    {

        private GameObject key;
        private bool attractKey, inUse;
        private Vector3 lastFrameValue;

        public override void StartUsing(GameObject usingObject)
        {
            //print("start using");
            if(!inUse)
            {
                inUse = true;
            }
            else
            {
                inUse = false;
                GameObject.Find("Safe/Magnet/MagDoorKey").SetActive(false);
                GameObject.Find("Safe/Magnet/MagDoorKey1").SetActive(true);
            }
        }

        // Use this for initialization
        protected override void Start()
        {
            base.Start();
            key = GameObject.Find("DoorKey");
            attractKey = false;
            inUse = false;
            lastFrameValue = Vector3.zero;
        }

        // Update is called once per frame
        protected override void Update()
        {
            
        }

        protected override void FixedUpdate()
        {
            base.FixedUpdate();
            if(attractKey && Vector3.Distance(transform.position, key.transform.position) < 1)
            {
                Vector3 forward = Vector3.Scale(gameObject.transform.forward, new Vector3(-0.15f, -0.15f, -0.15f));
                Vector3 targetForce = (gameObject.transform.position - key.transform.position + forward) * 150;
                lastFrameValue = targetForce;
                Vector3 deltaForce = targetForce - lastFrameValue;
                key.GetComponent<Rigidbody>().AddForce(targetForce - deltaForce*3);
            }
            
        }

        void OnTriggerEnter(Collider collision)
        {
            if (collision.gameObject.tag == "Key")
            {
                //print("Magnet/key collison");
                GameObject.Find("DoorKey").SetActive(false);

                //StopAttract();
                GameObject.Find("Safe/Magnet/MagDoorKey").SetActive(true);
            }
        }

        public void StopAttract ()
        {
            //print("Stop attract");
            attractKey = false;
            
        }

        public void OnGrab ()
        {
            //print("You Grabbed it!");
            attractKey = true;
        }
    }
}
