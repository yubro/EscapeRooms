﻿namespace VRTK
{
    using UnityEngine;

    public class FlashlightScript : VRTK_InteractableObject
    {
	    public AudioClip soundOn;
	    public AudioClip soundOff;

        private GameObject Light;
        private GameObject AreaLight;
        private GameObject Filter;
        private bool FilterActive;
        private bool LightActive;
	
	    public override void StartUsing(GameObject usingObject)
	    {
		    base.StartUsing(usingObject);
		    ToggleLight();
	    }
	
	    protected override void Start()
	    {
		    base.Start();
            Light = GameObject.Find("Flashlight/Light");
            LightActive = Light.activeSelf;
            AreaLight = GameObject.Find("Flashlight/AreaLight");
            Filter = GameObject.Find("Flashlight/Filter/Filter_base");
            Filter.SetActive(false);
            FilterActive = false;
        }

        public bool GetFilter()
        {
            return FilterActive;
        }

        public void ActivateFilter()
        {
            Filter.SetActive(true);
            FilterActive = true;
            Light.GetComponent<Light>().color = Color.blue;
            AreaLight.GetComponent<Light>().color = Color.blue;
        }

        public bool GetActive()
        {
            return LightActive;
        }

	    private void ToggleLight()
	    {
			if (Light.activeSelf == false)
			{

                Light.SetActive(true);
                AreaLight.SetActive(true);
                LightActive = true;
                gameObject.GetComponent<AudioSource>().clip = soundOn;
                gameObject.GetComponent<AudioSource>().Play();
            }

			else
			{
                Light.SetActive(false);
                AreaLight.SetActive(false);
                LightActive = false;
                gameObject.GetComponent<AudioSource>().clip = soundOff;
                gameObject.GetComponent<AudioSource>().Play();
            }
		}
	}
}﻿