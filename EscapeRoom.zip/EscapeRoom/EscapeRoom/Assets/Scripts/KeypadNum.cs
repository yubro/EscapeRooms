﻿namespace VRTK
{
    using UnityEngine;

    public class KeypadNum : VRTK_InteractableObject
    {
        public int number;

        public override void StartUsing(GameObject usingObject)
        {
            base.StartUsing(usingObject);
            if(GameObject.Find("Fusebox_Color").GetComponent<Fusebox_Color>().GetPower())
            {
                GameObject.Find("Safe/SafeDoor/Keypad").GetComponent<AudioSource>().Play();
                GameObject.Find("Safe/SafeDoor/Keypad/KeypadDisplayInput").GetComponent<KeypadInput>().AddInput(number.ToString());
            }
        }

        // Use this for initialization
        protected override void Start()
        {
            base.Start();
        }
    }
}