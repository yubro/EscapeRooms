﻿namespace VRTK
{

    using UnityEngine;

    public class Fuse_green : VRTK_InteractableObject
    {
        private GameObject fuse;

        protected override void Start()
        {
            base.Start();
            fuse = GameObject.Find("Fusebox/Fuse_green_in");
            fuse.SetActive(false);
        }

        void OnTriggerEnter(Collider collision)
        {
            if (collision.gameObject.name == "Fusebox")
            {
                gameObject.SetActive(false);

                fuse.SetActive(true);
                GameObject.Find("Fusebox").GetComponent<Fusebox>().Testfuses();
            }
        }
    }
}