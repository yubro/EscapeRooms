﻿using UnityEngine;
using System.Collections;

public class HiddenTexture : MonoBehaviour {
    private Transform tfLight;

	// Use this for initialization
	void Start () {
        // find the revealing light named "RevealingLight":
        var goLight = GameObject.Find("Flashlight/default/Light");
        if (goLight) tfLight = goLight.transform;
    }
	
	// Update is called once per frame
	void Update () {
        if (tfLight)
        {
            GetComponent<Renderer>().material.SetVector("_LightPos", tfLight.position);
            GetComponent<Renderer>().material.SetVector("_LightDir", tfLight.forward);
            GetComponent<Renderer>().material.SetFloat("_SpotAngle", 70f);
        }
    }
}
