﻿using UnityEngine;
using System.Collections;

public class KeyMagnetMover : MonoBehaviour {

    public float magnetStrength = 5f;
    public float distanceStrength = 10f;
    public int magnetDirection = 1;
    public bool looseMagnet = true;

    private Transform trans;
    private Rigidbody thisRB;
    private Transform magnetTrans;
    private bool magnetInZone;

    void Awake ()
    {
        trans = transform;
        thisRB = trans.GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        if (magnetInZone)
        {
            Vector3 directionToMagnet = magnetTrans.position - trans.position;
            float distance = Vector3.Distance(magnetTrans.position, trans.position);
            float magnetDistanceStr = (distanceStrength / distance) * magnetStrength;

            thisRB.AddForce(magnetDistanceStr * (directionToMagnet * magnetDirection), ForceMode.Force);
        }
    }

    void OnTriggerEnter (Collider other)
    {
        if (other.tag == "Magnet")
        {
            magnetTrans = other.transform;
            magnetInZone = true;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag == "Magnet" && looseMagnet)
        {
            magnetInZone = false;
        }
    }
}
