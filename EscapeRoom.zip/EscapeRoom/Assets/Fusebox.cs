﻿using UnityEngine;
using System.Collections;

public class Fusebox : MonoBehaviour {
    private GameObject Light;

	// Use this for initialization
	void Start () {
        Light = GameObject.Find("RoomLight/Point Light");
        Light.SetActive(false);
    }
	
	// Update is called once per frame
	void Update () {
	
	}

    public void Testfuses ()
    {
        bool red = GameObject.Find("Fusebox/Fuse_red_in").activeSelf;
        bool green = GameObject.Find("Fusebox/Fuse_green_in").activeSelf;
        bool blue = GameObject.Find("Fusebox/Fuse_blue_in").activeSelf;

        if(red && green && blue)
        {
            Light.SetActive(true);
        }
    }
}
