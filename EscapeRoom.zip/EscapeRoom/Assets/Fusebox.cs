﻿using UnityEngine;
using System.Collections;

public class Fusebox : MonoBehaviour {

    private GameObject Light;
    private bool red;
    private bool green;
    private bool blue;
    private bool power;

	// Use this for initialization
	void Start () {
        Light = GameObject.Find("RoomLight/Point Light");
        Light.SetActive(false);

        red = false;
        green = false;
        blue = false;

        power = false;
    }
	
	public bool GetPower ()
    {
        return power;
    }

    public void Testfuses ()
    {
        if(GameObject.Find("Fusebox/Fuse_red_in") != null)
        {
            red = GameObject.Find("Fusebox/Fuse_red_in").activeSelf;
        }
        if (GameObject.Find("Fusebox/Fuse_green_in") != null)
        {
            green = GameObject.Find("Fusebox/Fuse_green_in").activeSelf;
        }
        if (GameObject.Find("Fusebox/Fuse_blue_in") != null)
        {
            blue = GameObject.Find("Fusebox/Fuse_blue_in").activeSelf;
        }

        if(red && green && blue)
        {
            Light.SetActive(true);
            power = true;
        }
    }
}
