﻿namespace VRTK.Examples
{
    using UnityEngine;

    public class KeyScript : VRTK_InteractableObject
    {

        void OnTriggerEnter(Collider collision)
        {
            // print (gameObject.name + " " + collision.gameObject.name);
            if (collision.gameObject.name == "Keyhole")
            {
                //gameObject.SetActive(false);
                ForceStopInteracting();
                this.isGrabbable = false;
                this.touchHighlightColor = Color.clear;
                gameObject.SetActive(false);

                GameObject.Find("Door").GetComponent<DoorScript>().unlock();
                GameObject.Find("GrabDoor/Door/KeyIn").SetActive(true);
            }
            // print ("COLLIDED");
        }

        public override void StartUsing(GameObject usingObject)
        {
            
        }

        protected override void Start()
        {

        }
        
    }
}