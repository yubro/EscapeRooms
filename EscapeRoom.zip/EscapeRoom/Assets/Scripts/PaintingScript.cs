﻿namespace VRTK
{

    using UnityEngine;
    using System.Collections;

    public class PaintingScript : MonoBehaviour
    {
        private Transform tfLight;

        // Use this for initialization
        void Start()
        {
            // find the revealing light named "RevealingLight":
            var Light = GameObject.Find("Flashlight/Light");
            if (Light) tfLight = Light.transform;
        }

        // Update is called once per frame
        void Update()
        {
            bool Light = GameObject.Find("Flashlight").GetComponent<FlashlightScript>().GetActive();
            bool Filter = GameObject.Find("Flashlight").GetComponent<FlashlightScript>().GetFilter();

            if (tfLight && Light && Filter)
            {
                GetComponent<Renderer>().material.SetVector("_LightPos", tfLight.position);
                GetComponent<Renderer>().material.SetVector("_LightDir", tfLight.forward);
                GetComponent<Renderer>().material.SetFloat("_SpotAngle", 70f);
            }
            else
            {
                GetComponent<Renderer>().material.SetVector("_LightPos", tfLight.position);
                GetComponent<Renderer>().material.SetVector("_LightDir", tfLight.forward);
                GetComponent<Renderer>().material.SetFloat("_SpotAngle", 0f);
            }
        }
    }

}

/*
 * namespace VRTK
{
    using UnityEngine;

    public class PaintingScript : MonoBehaviour
    {
        private Transform tfLight;
        // Use this for initialization
        void Start()
        {
            // find the revealing light
            var Light = GameObject.Find("Flashlight/Light");
            if (Light) tfLight = Light.transform;
        }

        // Update is called once per frame
        void Update()
        {
            bool Light = GameObject.Find("Flashlight").GetComponent<FlashlightScript>().GetActive();
            bool Filter = GameObject.Find("Flashlight").GetComponent<FlashlightScript>().GetFilter();

            if (tfLight)
            {
                GetComponent<Renderer>().material.SetVector("_LightPos", tfLight.position);
                GetComponent<Renderer>().material.SetVector("_LightDir", tfLight.forward);
                GetComponent<Renderer>().material.SetFloat("_SpotAngle", 70f);
            }
            else
            {
                GetComponent<Renderer>().material.SetVector("_LightPos", tfLight.position);
                GetComponent<Renderer>().material.SetVector("_LightDir", tfLight.forward);
                GetComponent<Renderer>().material.SetFloat("_SpotAngle", 0f);
            }
        }
    }
} */
