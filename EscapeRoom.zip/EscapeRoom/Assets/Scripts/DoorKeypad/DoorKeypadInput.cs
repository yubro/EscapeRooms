﻿namespace VRTK
{
    using UnityEngine;
    using System.Collections;

    public class DoorKeypadInput : MonoBehaviour
    {
        private bool Unlocked;
        private string input;
        private string pass = "691";
        private GameObject Door;

        // Use this for initialization
        void Start()
        {
            Unlocked = false;
            input = "";
            gameObject.GetComponent<TextMesh>().text = "";
        }

        public void AddInput(string num)
        {
            if (input.Length <= 8)
            {
                input = input + num;
            }
            else
            {
                input = input.Substring(1) + num;
            }
            gameObject.GetComponent<TextMesh>().text = input;
        }

        public void TestPass()
        {
            if (string.Compare(input, pass) == 0)
            {
                input = "";
                gameObject.GetComponent<TextMesh>().text = "UNLOCKED";
                Unlocked = true;
                GameObject.Find("DoorKeypad/Upperlock").GetComponent<MeshRenderer>().enabled = false;
                GameObject.Find("DoorKeypad/Lowerlock").GetComponent<MeshRenderer>().enabled = false;
                GameObject.Find("GrabDoor/Door").GetComponent<DoorScript>().TestLock();
            }
            else
            {
                input = "";
                gameObject.GetComponent<TextMesh>().text = "ERROR";
            }
        }

        public void ClearInput()
        {
            input = "";
            gameObject.GetComponent<TextMesh>().text = input;
        }

        public bool GetStatus()
        {
            return Unlocked;
        }
    }
}