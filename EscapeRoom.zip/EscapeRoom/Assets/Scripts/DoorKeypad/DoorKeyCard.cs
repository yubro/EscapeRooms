﻿using UnityEngine;
using System.Collections;

public class DoorKeyCard : MonoBehaviour {

    private bool CardSwiped;
    
    // Use this for initialization
	void Start () {
        CardSwiped = false;
	}

    void OnTriggerEnter(Collider collision)
    {
        bool Power = GameObject.Find("Fusebox_Color").GetComponent<Fusebox_Color>().GetPower();
        if (collision.gameObject.name == "StripTrigger" && Power)
        {
            CardSwiped = true;
        }
    }

    public bool GetStatus()
    {
        return CardSwiped;
    }

    // Update is called once per frame
    void Update () {
	
	}
}
