﻿namespace VRTK
{

    using UnityEngine;

    public class Fuse_red : VRTK_InteractableObject
    {
        private GameObject fuse;

        protected override void Start()
        {
            base.Start();
            fuse = GameObject.Find("Fusebox_Color/Fuse_red_in");
            fuse.GetComponent<MeshRenderer>().enabled = false;
        }

        void OnTriggerEnter(Collider collision)
        {
            if (collision.gameObject.name == "Fuse_red_in")
            {
                gameObject.SetActive(false);

                fuse.GetComponent<MeshRenderer>().enabled = true;
                fuse.GetComponent<MeshCollider>().isTrigger = false;
                GameObject.Find("Fusebox_Color").GetComponent<Fusebox_Color>().Testfuses();
            }
        }
    }
}