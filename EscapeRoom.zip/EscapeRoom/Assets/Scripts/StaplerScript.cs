﻿namespace VRTK
{
    using UnityEngine;

    public class StaplerScript : VRTK_InteractableObject
    {
        private GameObject staple;
        private float stapleSpeed = 20f;
        private float stapleLife = 5f;

        public override void StartUsing(GameObject usingObject)
        {
            base.StartUsing(usingObject);
            FireStaple();
        }

        protected override void Start()
        {
            base.Start();
            staple = transform.Find("Staple").gameObject;
            staple.SetActive(false);
        }

        private void FireStaple()
        {
            GameObject stapleClone = Instantiate(staple, staple.transform.position, staple.transform.rotation) as GameObject;
            stapleClone.SetActive(true);
            Rigidbody rb = stapleClone.GetComponent<Rigidbody>();
            rb.AddForce(staple.transform.forward * stapleSpeed);
            stapleClone.transform.localScale = staple.transform.lossyScale;
            Destroy(stapleClone, stapleLife);
        }
    }
}