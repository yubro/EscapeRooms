﻿using UnityEngine;
using System.Collections;

public class DialScript2 : MonoBehaviour {
    private GameObject text;
	private float pass = 42f;
    private float num;
	private float previous_num = 0f;
	private GameObject Door;
	private AudioSource audio;
    float starttime = 0;
    float currtime = 0;
    private bool on42 = false;

    // Use this for initialization
    void Start () {
		audio = gameObject.GetComponent<AudioSource>();
        text = GameObject.Find("Safe/SafeDoor/DialItems/Dial Text");
		Door = GameObject.Find("Safe/SafeDoor");
		Door.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeAll;
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 angles = transform.localEulerAngles;
        float x = Mathf.Floor(angles.x);
        float y = Mathf.Floor(angles.y);
        float z = Mathf.Floor(angles.z);
        float number = Mathf.Floor(360f / 360f * (360 - angles.y));
        //text.GetComponent<TextMesh>().text = x.ToString() + ", " + y.ToString() + ", " + z.ToString();

        if (number == 360f)
        {
            number = 0;
        }

        text.GetComponent<TextMesh>().text = number.ToString();

        num = number;

        Debug.Log("num = " + num + " previous num = " + previous_num);

        if (num != previous_num && num == 42f)
        {
            currtime = Time.time;
            if (!on42)
            {
                starttime = Time.time;
                on42 = true;
            }
            else if (currtime - starttime > 2 && starttime != 0)
            {
                text.GetComponent<TextMesh>().text = "UNLOCKED";
                Door.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
                audio.Play();
                this.enabled = false;
            }
        }
        else
        {
            on42 = false;
            previous_num = num;
        }
    }
}
