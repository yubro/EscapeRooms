﻿namespace VRTK
{
    using UnityEngine;
    using System.Collections;

    public class MagnetScript : VRTK_InteractableObject
    {

        private GameObject key;
        private bool attractKey;
        private Vector3 lastFrameValue;

        public override void StartUsing(GameObject usingObject)
        {
            
        }

        // Use this for initialization
        protected override void Start()
        {
            base.Start();
            key = GameObject.Find("DoorKey");
            attractKey = false;
            lastFrameValue = Vector3.zero;
        }

        // Update is called once per frame
        protected override void Update()
        {
            
        }

        protected override void FixedUpdate()
        {
            base.FixedUpdate();
            if(attractKey && Vector3.Distance(transform.position, key.transform.position) < 1)
            {
                Vector3 forward = Vector3.Scale(gameObject.transform.forward, new Vector3(-0.15f, -0.15f, -0.15f));
                Vector3 targetForce = (gameObject.transform.position - key.transform.position + forward) * 150;
                lastFrameValue = targetForce;
                Vector3 deltaForce = targetForce - lastFrameValue;
                key.GetComponent<Rigidbody>().AddForce(targetForce - deltaForce*3);
            }
            
        }

        public void StopAttract ()
        {
            attractKey = false;
        }

        public void OnGrab ()
        {
            //print("You Grabbed it!");
            attractKey = true;
        }
    }
}
