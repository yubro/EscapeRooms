﻿namespace VRTK
{
    using UnityEngine;
    using System.Collections;

    public class JewelryBox_KeyScript : VRTK_InteractableObject
    {
        private GameObject Key;
        void OnTriggerEnter(Collider collision)
        {
            if(collision.gameObject.name == "JewelryBox_Keyhole")
            {
                gameObject.SetActive(false);

                FixedJoint fixedjoint = GameObject.Find("JewelryBox/Lid").GetComponent<FixedJoint>();
                Destroy(fixedjoint);
                fixedjoint = GameObject.Find("KeyCard").GetComponent<FixedJoint>();
                Destroy(fixedjoint);
                Key.SetActive(true);
            }
        }

        public override void StartUsing(GameObject usingObject)
        {

        }

        protected override void Start()
        {
            Key = GameObject.Find("JewelryBox/Base/JewelryBox_Key_in");
            Key.SetActive(false);
        }

        protected override void Update()
        {

        }
    }
}
