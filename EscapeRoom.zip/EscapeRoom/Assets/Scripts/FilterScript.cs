﻿namespace VRTK
{
    using UnityEngine;

    public class FilterScript : VRTK_InteractableObject
    {

        void OnTriggerEnter(Collider collision)
        {
            if (collision.gameObject.name == "Filter_Collision")
            {
                GameObject.Find("Flashlight").GetComponent<FlashlightScript>().ActivateFilter();
                gameObject.SetActive(false);
            }
        }

        public override void StartUsing(GameObject usingObject)
        {

        }

        protected override void Start()
        {

        }

    }
}