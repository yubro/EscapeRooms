﻿using UnityEngine;
using System.Collections;
namespace VRTK
{

    public class KeyMagnetController : VRTK_InteractableObject
    {
        public bool inUse;

        public override void StartUsing(GameObject usingObject)
        {
            base.StartUsing(usingObject);
            print("Using Magnet " + inUse);
            if(inUse == false)
            {
                inUse = true;
            }
            else
            {
                inUse = false;
            }
        }

        protected override void Start()
        {
            base.Start();
            inUse = false;
        }

        
    }
}