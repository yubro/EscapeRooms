﻿namespace VRTK
{
    using UnityEngine;

    public class KeypadEnter : VRTK_InteractableObject
    {
        public override void StartUsing(GameObject usingObject)
        {
            base.StartUsing(usingObject);
            if (GameObject.Find("Fusebox").GetComponent<Fusebox_Color>().GetPower())
            {
                GameObject.Find("Safe/SafeDoor/Keypad").GetComponent<AudioSource>().Play();
                GameObject.Find("Safe/SafeDoor/Keypad/KeypadDisplayInput").GetComponent<KeypadInput>().TestPass();
            }
        }

        // Use this for initialization
        protected override void Start()
        {
            base.Start();
        }
    }
}