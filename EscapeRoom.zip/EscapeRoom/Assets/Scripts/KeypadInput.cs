﻿using UnityEngine;
using System.Collections;

public class KeypadInput : MonoBehaviour {

    private string input = "";
    private string pass = "5471236";
    private GameObject Door;
    
    // Use this for initialization
	void Start () {
        gameObject.GetComponent<TextMesh>().text = "";
        Door = GameObject.Find("Safe/SafeDoor");
        Door.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeAll;
	}

    public void AddInput (string num)
    {
        if(input.Length <= 8)
        {
            input = input + num;
        }
        else
        {
            input = input.Substring(1) + num;
        }
        gameObject.GetComponent<TextMesh>().text = input;
    }

    public void TestPass ()
    {
        if(string.Compare(input, pass) == 0)
        {
            input = "";
            gameObject.GetComponent<TextMesh>().text = "UNLOCKED";
            Door.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.None;
        }
        else
        {
            input = "";
            gameObject.GetComponent<TextMesh>().text = "ERROR";
        }
    }
	
    public void ClearInput ()
    {
        input = "";
        gameObject.GetComponent<TextMesh>().text = input;
    }
}
