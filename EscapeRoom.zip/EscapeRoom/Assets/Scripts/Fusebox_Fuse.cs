﻿using UnityEngine;
using System.Collections;

public class Fusebox_Fuse : MonoBehaviour {

	// Use this for initialization
	void Start () {
        GetComponent<MeshRenderer>().enabled = false;
	}

    void OnTriggerEnter(Collider collision)
    {
        if(collision.gameObject.tag == "Fuse")
        {
            collision.gameObject.SetActive(false);
            GetComponent<MeshRenderer>().enabled = true;
            GetComponent<MeshCollider>().isTrigger = false;
        }
    }

        // Update is called once per frame
        void Update () {
	
	}
}
