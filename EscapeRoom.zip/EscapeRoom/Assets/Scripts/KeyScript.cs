﻿namespace VRTK
{
    using UnityEngine;

    public class KeyScript : VRTK_InteractableObject
    {
        private GameObject KeyIn;
        void OnTriggerEnter(Collider collision)
        {
            if (collision.gameObject.name == "Keyhole")
            {
                gameObject.SetActive(false);
                
                KeyIn.GetComponent<MeshRenderer>().enabled = true;
                GameObject.Find("GrabDoor/Door").GetComponent<DoorScript>().TestLock();
            }
        }

        public override void StartUsing(GameObject usingObject)
        {
            
        }

        protected override void Start()
        {
            KeyIn = GameObject.Find("GrabDoor/Door/KeyIn");
            KeyIn.GetComponent<MeshRenderer>().enabled = false;
        }
    }
}