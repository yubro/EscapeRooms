﻿namespace VRTK
{
    using UnityEngine;

    public class KeyScript : VRTK_InteractableObject
    {
        private bool Unlocked;
        void OnTriggerEnter(Collider collision)
        {
            if (collision.gameObject.name == "Keyhole")
            {
                gameObject.SetActive(false);

                //GameObject.Find("Door").GetComponent<DoorScript>().unlock();
                Unlocked = true;
                GameObject.Find("GrabDoor/Door/KeyIn").SetActive(true);
                GameObject.Find("GrabDoor/Door").GetComponent<DoorScript>().TestLock();
            }
        }

        public override void StartUsing(GameObject usingObject)
        {
            
        }

        protected override void Start()
        {
            Unlocked = false;
        }
        
        public bool GetStatus()
        {
            return Unlocked;
        }
    }
}