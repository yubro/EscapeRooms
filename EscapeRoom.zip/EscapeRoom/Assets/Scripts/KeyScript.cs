﻿namespace VRTK
{
    using UnityEngine;

    public class KeyScript : VRTK_InteractableObject
    {

        void OnTriggerEnter(Collider collision)
        {
            if (collision.gameObject.name == "Keyhole")
            {
                gameObject.SetActive(false);

                GameObject.Find("Door").GetComponent<DoorScript>().unlock();
                GameObject.Find("GrabDoor/Door/KeyIn").SetActive(true);
            }
        }

        public override void StartUsing(GameObject usingObject)
        {
            
        }

        protected override void Start()
        {

        }
        
    }
}