﻿namespace VRTK{

using UnityEngine;

public class flashlight : VRTK_InteractableObject
{
	public AudioClip soundOn;
	public AudioClip soundOff;

	
	public override void StartUsing(GameObject usingObject)
	{
		base.StartUsing(usingObject);
		LightItUp();
	}
	
	protected override void Start()
	{
			base.Start();
	}

	private void LightItUp()

	{
			if (GameObject.Find("Flashlight/default/Light").active == false)
			{

                GameObject.Find("Flashlight/default/Light").SetActive(true);
                //GetComponent<AudioSource>().clip = soundOn;
				//GetComponent<AudioSource>().Play();
			}

			else
			{
                GameObject.Find("Flashlight/default/Light").SetActive(false);
				//GetComponent<AudioSource>().clip = soundOff;
				//GetComponent<AudioSource>().Play();

			}
		}
	}
}﻿