﻿namespace VRTK{

using UnityEngine;

public class flashlightCopy : VRTK_InteractableObject
{
	public AudioClip soundOn;
	public AudioClip soundOff;

	
	public override void StartUsing(GameObject usingObject)
	{
		base.StartUsing(usingObject);
		LightItUp();
	}
	
	protected override void Start()
	{
			base.Start();
	}

	private void LightItUp()

	{
			if (GameObject.Find("Flashlight/default/Light").activeSelf == false)
			{

                GameObject.Find("Flashlight/default/Light").SetActive(true);
                GameObject.Find("Flashlight/default/AreaLight").SetActive(true);
                gameObject.GetComponent<AudioSource>().clip = soundOn;
                gameObject.GetComponent<AudioSource>().Play();
            }

			else
			{
                GameObject.Find("Flashlight/default/Light").SetActive(false);
                GameObject.Find("Flashlight/default/AreaLight").SetActive(false);
                gameObject.GetComponent<AudioSource>().clip = soundOff;
                gameObject.GetComponent<AudioSource>().Play();

            }
		}
	}
}﻿