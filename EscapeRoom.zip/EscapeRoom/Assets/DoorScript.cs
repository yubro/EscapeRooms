﻿namespace VRTK.Examples
{
    using UnityEngine;
    using System.Collections;

    public class DoorScript : VRTK_InteractableObject
    {
        private Rigidbody body;
        // Use this for initialization
        protected override void Start()
        {
            body = gameObject.GetComponent<Rigidbody>();
            this.isGrabbable = false;
            body.constraints = RigidbodyConstraints.FreezePosition;
        }

        public void unlock()
        {
            this.isGrabbable = true;
            body.constraints = RigidbodyConstraints.None;
            print("Unlocking Door");
        }
    }
}
