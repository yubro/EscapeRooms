﻿using UnityEngine;
using System.Collections;

public class DialScript : MonoBehaviour {
    private GameObject text;

	// Use this for initialization
	void Start () {
        text = GameObject.Find("Dial Text");
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 angles = transform.localEulerAngles;
        float x = Mathf.Floor(angles.x);
        float y = Mathf.Floor(angles.y);
        float z = Mathf.Floor(angles.z);
        float number = Mathf.Floor(40f / 360f * (360 - angles.y));
        //text.GetComponent<TextMesh>().text = x.ToString() + ", " + y.ToString() + ", " + z.ToString();
        text.GetComponent<TextMesh>().text = number.ToString();
    }
}
