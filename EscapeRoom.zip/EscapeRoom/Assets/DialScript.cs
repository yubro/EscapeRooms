﻿using UnityEngine;
using System.Collections;

public class DialScript : MonoBehaviour {
    private GameObject text;
	private float pass = 42f;
    private float num;
	private float previous_num = 500f;
	private GameObject Door;
	private AudioSource[] audio;
	private int timer = 0;
    private bool TryAgain = false;
	// Use this for initialization
	void Start () {
		audio = gameObject.GetComponents<AudioSource>();
        text = GameObject.Find("Dial Text");
		Door = GameObject.Find("BackPlate");
		Door.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeAll;
	}
	
	// Update is called once per frame
	void Update () {
            Vector3 angles = transform.localEulerAngles;
            float x = Mathf.Floor(angles.x);
            float y = Mathf.Floor(angles.y);
            float z = Mathf.Floor(angles.z);
            float number = Mathf.Floor(360f / 360f * (360 - angles.y));
        //text.GetComponent<TextMesh>().text = x.ToString() + ", " + y.ToString() + ", " + z.ToString();
        
        if (!TryAgain)
        {
            text.GetComponent<TextMesh>().text = number.ToString();
        }

            num = number;

            Debug.Log("num = " + num + " previous num = " + previous_num + "timer =" + timer);

            if (timer == 100 && num != previous_num)
            {
                timer = 0;
                CheckInput(num);
                previous_num = num;
        }
            timer++;
            if (timer > 100)
            {
                timer = 0;
            }
    }

	void CheckInput(float num){
		if (num == pass) {
			text.GetComponent<TextMesh> ().text = "UNLOCKED";
			Door.GetComponent<Rigidbody> ().constraints = RigidbodyConstraints.None;
			audio[0].Play();
            this.enabled = false;
        } 
		else {
			text.GetComponent<TextMesh> ().text = "TRY AGAIN";
            TryAgain = true;
			audio[1].Play();
            StartCoroutine("waiter");
        }
	}

	IEnumerator waiter() {
        //text.GetComponent<TextMesh>().text = "TRY AGAIN";
        yield return new WaitForSeconds(2.0f);
        TryAgain = false;

    }
}
