﻿using UnityEngine;
using System.Collections;

public class KeyMagnetController : MonoBehaviour {

	void OnTriggerEnter (Collider other)
    {

    }
}
